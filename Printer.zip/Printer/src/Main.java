public class Main {
    public static void main(String[] args) {
        Printer a = new Printer();
        a.append("Text to print1", "Document name: Document1", 5 );
        a.append("Text to print2", "Document name: Document2", 5);
        a.append("Text to print3", "Document name: Document3 ");
        a.append("Text to print4");

        System.out.println("Total pending page: " + a.getPendingPagesCount()) ;
        System.out.println(" \n ");
        a.print();
        System.out.println("Total pending page: " + a.getPendingPagesCount()) ;
        System.out.println("Total printed page: " + a.getTotalPagesCount()) ;

    }
}
