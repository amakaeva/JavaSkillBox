public class Printer {
    String queue = "";  // List of documents to print
    int printedCount = 0;
    int pendingPagesCount = 0;

    public void append (String text) {
        this.queue = this.queue + text + "\n";
    }

    public void append (String text, String name) {
        this.append(text);
        this.append(name);
    }

    public void append (String text, String name, int count) {
        this.append(text);
        this.append(name);
        this.queue =  this.queue + "Page count: " + count + "\n";
        this.pendingPagesCount = this.pendingPagesCount + count;
        this.printedCount = this.printedCount + count;
    }

    public void clear () {
        this.queue = "";
        this.pendingPagesCount = 0;
    }

    public void print () {
        System.out.println(this.queue);
        this.clear();

    }

    public int getPendingPagesCount () {
         return this.pendingPagesCount;
    }

    public int getTotalPagesCount () {
        return this.printedCount;
    }

}
