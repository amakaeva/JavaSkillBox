public class Main {
    public static void main(String[] args) {
        Basket vasyaBasket = new Basket();
        Basket petyaBasket = new Basket(50);
        Basket mashaBasket = new Basket("Table", 5000);

        vasyaBasket.add("Bread", 25);
        vasyaBasket.add("Sugar", 45);


        petyaBasket.add("Hammer", 20, 1,5.5);
        petyaBasket.add("knife", 15, 2,6.7);
        petyaBasket.add("Pan", 200, 3,9.7);

        vasyaBasket.print("Vasiya basket items: ");
        System.out.println("");
        petyaBasket.print("Petya basket items: ");
        System.out.println("");
        mashaBasket.print("Masha Basket: ");
    }

}
