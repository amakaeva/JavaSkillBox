public class Basket {
    private  String items = "";
    private  int totalPrice = 0;
    int limit = 0;
    double totalWeight = 0;

    // Contructor
    public Basket() {
        items = "List of goods";
        this.limit = 100000;
    }

    public Basket(int limit) {
        this(); // constructor call without param
        this.limit = limit; // this - global variable, limit - parameter
    }

    public  Basket(String items, int totalPrice) {
        this();
        this.items = this.items + "\n" + items;
        this.totalPrice = totalPrice;

    }

    public void add(String name, int price) {
        if(contains1(name)){
            return;
        }
        if (totalPrice + price >= limit) {
            return;
        }
       items = items + "\n" + name + " - " + price;
       totalPrice = totalPrice + price;
       //totalWeight = 0;
    }

    public void add(String name, int price, int count, double weight)
    {
        add(name, price);
        if (totalPrice + price > limit) {
            return;
        } else {
            items = items + ", weight = " + weight;
            totalWeight = totalWeight + weight;
        }
    }

    public double getTotalWeight() {
        return totalWeight;
    }

    public  void clear() {
        items = "";
        totalPrice = 0;
    }

    public  int getTotalPrice() {
        return totalPrice;
    }

    public  boolean contains1(String name) {
        return items.contains(name);
    }

    public  void print (String title){
        System.out.println(title);
        if(items.isEmpty()){
            System.out.println("Корзина пуста");
        } else {
            System.out.println(items);
            System.out.println("Общий вес: " + getTotalWeight());
        }
    }
}
