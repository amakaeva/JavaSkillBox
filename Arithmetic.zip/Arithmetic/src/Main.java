public class Main {
    public static void main(String[] args) {
        Arithmetic b = new Arithmetic();
        b.var1 = 10;
        b.var2 = 25;
        System.out.println("Максимальное число из двух чисел: " + b.var1 + " и " + b.var2 + " = " + b.max());
        System.out.println("Минимальное число из двух: " + b.var1 + " и " + b.var2 + " = " + b.min());
        System.out.println("Сумма двух чисел: " + b.var1 + " + " + b.var2 + " = " + b.summa());
        System.out.println("Произведение двух чисел: " + b.var1 + " * " + b.var2 + " = " + b.multiply());
    }
}
