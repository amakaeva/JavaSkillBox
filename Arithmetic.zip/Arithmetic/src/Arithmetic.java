public class Arithmetic {
    int var1 = 0, var2 = 0;

    public void  Arithmetic (int par1, int par2) {
        this.var1 = par1;
        this.var2 = par2;
    }

    public int summa() {
        int summa = this.var1 + this.var2;
        return summa;
    }

    public int multiply() {
        int multiply = this.var1 * this.var2;
        return multiply;
    }

    public int max() {
        if (this.var1 > this.var2) {
            return this.var1;
        }
        else if (this.var1 < this.var2) {
            return this.var2;
        }
        else return this.var1;
    }

    public int min() {
        if (this.var1 > this.var2)
        {
            return this.var2;
        }
        else if (this.var1 < this.var2) {
            return this.var1;
        }
        else return this.var1;
    }


}
